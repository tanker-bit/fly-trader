"""Live 8-bit dashboard: an animated pixel-art fly that researches, buys, sells, holds or falls asleep, with a live leaderboard.

    pip install pygame-ce
    python -m experiments.visual_dashboard                          # window, reads league_data_fundamentals/
    python -m experiments.visual_dashboard --selftest               # no window: draws 30 frames, saves dashboard_selftest.png

Keys: SPACE pause   TAB next agent   ESC / Q quit.
It only READS files (state.json, agents/*, rounds/*, the SEC cache); polling runs in a background thread, so the league's
worker processes are never slowed or touched. Trades shown are a REPLAY of one agent's saved out-of-sample scores
(rounds/scores/*.npz, saved by the v6 league code); the league itself places no real trades.
"""
from __future__ import annotations

import argparse
import os
import sys

from dashboard.app import DashboardApp
from dashboard.canvas_pygame import PygameCanvas
from dashboard.scene import H, W, draw_scene


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--league-root", default="league_data_fundamentals")
    ap.add_argument("--panel", default="data_fundamentals/panel.parquet")
    ap.add_argument("--sec-root", default="data_fundamentals/sec")
    ap.add_argument("--universe-dir", default="data_fundamentals/universe")
    ap.add_argument("--agent", default=None, help="show this agent id (default: the current top fly)")
    ap.add_argument("--poll", type=float, default=2.0, help="seconds between disk polls")
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--selftest", action="store_true", help="headless check of the pygame path")
    a = ap.parse_args(argv)
    if a.selftest:
        os.environ["SDL_VIDEODRIVER"] = "dummy"
    try:
        import pygame
    except ImportError:
        sys.exit("pygame is not installed: pip install pygame-ce")
    pygame.init()
    pygame.display.set_caption("Fly-Trader League")
    screen = pygame.display.set_mode((W, H), pygame.SCALED | pygame.RESIZABLE)
    cv = PygameCanvas(screen, pygame)
    app = DashboardApp(a.league_root, a.panel, a.sec_root, a.universe_dir, a.agent, a.poll, start_threads=not a.selftest)
    if a.selftest:
        app.poll_once()
    clock = pygame.time.Clock()
    frames = 0
    while not app.quit:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                app.quit = True
            elif e.type == pygame.KEYDOWN:
                if e.key in (pygame.K_ESCAPE, pygame.K_q):
                    app.quit = True
                elif e.key == pygame.K_SPACE:
                    app.toggle_pause()
                elif e.key == pygame.K_TAB:
                    app.next_agent()
        dt = min(clock.tick(a.fps) / 1000.0, 0.1)
        app.update(dt)
        draw_scene(cv, app.view())
        pygame.display.flip()
        frames += 1
        if a.selftest and frames >= 30:
            pygame.image.save(screen, "dashboard_selftest.png")
            print(f"selftest ok: {frames} frames drawn, saved dashboard_selftest.png (state {app.animator.state}, "
                  f"mode {app.snap.mode}, round {app.snap.round}, {len(app.snap.agents)} agents)")
            break
    app.quit = True
    pygame.quit()


if __name__ == "__main__":
    main()
