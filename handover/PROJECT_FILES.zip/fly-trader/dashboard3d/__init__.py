"""Low-poly synthwave 3D scene for the fly dashboard (numpy geometry; renderers are in render_soft.py and render_gl.py)."""
